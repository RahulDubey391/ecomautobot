# Module 2: 50+ Copy-Paste Edge Endpoints, Schemas & Middleware

This deliverable contains production-grade, zero-dependency/minimal-dependency implementations for edge infrastructure powered by Cloudflare Workers and Hono.js. Every block is hardened against timing attacks, memory leaks, and distributed race conditions.

---

## 1. Production Middleware Engine

### 1.1 Enterprise Security Headers & Dynamic CORS Middleware

Replaces generic CORS setups with a strict Origin-reflection model, Content Security Policy (CSP), HTTP Strict Transport Security (HSTS), and resource isolation headers.

```typescript
// src/middleware/security.ts
import { Context, Next } from 'hono';

interface CorsOptions {
  allowedOrigins: string[];
  allowedMethods: string[];
  allowedHeaders: string[];
  exposedHeaders: string[];
  maxAge: number;
  credentials: boolean;
}

const DEFAULT_CORS_OPTIONS: CorsOptions = {
  allowedOrigins: ['https://production.tenant-domain.com', 'https://admin.tenant-domain.com'],
  allowedMethods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'X-Tenant-ID'],
  exposedHeaders: ['Content-Range', 'X-Content-Range', 'X-RateLimit-Limit', 'X-RateLimit-Remaining'],
  maxAge: 86400,
  credentials: true,
};

export const securityHeaders = () => {
  return async (c: Context, next: Next) => {
    await next();

    // Enforce modern TLS & Resource Isolation
    c.res.headers.set('Strict-Transport-Security', 'max-age=63072000; includeSubDomains; preload');
    c.res.headers.set('X-Content-Type-Options', 'nosniff');
    c.res.headers.set('X-Frame-Options', 'DENY');
    c.res.headers.set('X-XSS-Protection', '0');
    c.res.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');
    c.res.headers.set('Cross-Origin-Embedder-Policy', 'require-corp');
    c.res.headers.set('Cross-Origin-Opener-Policy', 'same-origin');
    c.res.headers.set('Cross-Origin-Resource-Policy', 'same-site');
    c.res.headers.set(
      'Permissions-Policy',
      'accelerometer=(), camera=(), geolocation=(), gyroscope=(), magnetometer=(), microphone=(), payment=(), usb=()'
    );
    c.res.headers.set(
      'Content-Security-Policy',
      "default-src 'self'; frame-ancestors 'none'; object-src 'none'; base-uri 'none';"
    );
  };
};

export const cors = (options: Partial<CorsOptions> = {}) => {
  const config = { ...DEFAULT_CORS_OPTIONS, ...options };

  return async (c: Context, next: Next) => {
    const origin = c.req.header('Origin');

    if (!origin) {
      if (c.req.method === 'OPTIONS') {
        return c.text('', 204);
      }
      return await next();
    }

    const isAllowed = config.allowedOrigins.includes(origin) || config.allowedOrigins.includes('*');

    if (isAllowed) {
      c.res.headers.set('Access-Control-Allow-Origin', origin);
      c.res.headers.set('Vary', 'Origin');

      if (config.credentials) {
        c.res.headers.set('Access-Control-Allow-Credentials', 'true');
      }
    }

    if (c.req.method === 'OPTIONS') {
      if (!isAllowed) {
        return c.text('CORS Origin Forbidden', 403);
      }

      c.res.headers.set('Access-Control-Allow-Methods', config.allowedMethods.join(', '));
      c.res.headers.set('Access-Control-Allow-Headers', config.allowedHeaders.join(', '));
      c.res.headers.set('Access-Control-Expose-Headers', config.exposedHeaders.join(', '));
      c.res.headers.set('Access-Control-Max-Age', config.maxAge.toString());

      return c.text('', 204);
    }

    await next();
  };
};
```

---

### 1.2 Cryptographic Edge JWT Auth Engine with RBAC

Leverages Cloudflare's Web Crypto runtime via `jose` to verify RS256/EdDSA JWTs, extract tenant claims, and enforce role-based access control without hitting remote identity backends.

```typescript
// src/middleware/jwt-rbac.ts
import { Context, Next } from 'hono';
import { jwtVerify, importSPKI, importJWK, JWTPayload } from 'jose';

export interface EdgeJwtPayload extends JWTPayload {
  sub: string;
  tid: string; // Tenant ID
  roles: string[];
  permissions: string[];
}

export interface AuthContextVariables {
  jwtPayload: EdgeJwtPayload;
  userId: string;
  tenantId: string;
}

export const edgeAuth = (publicKeyPem: string, issuer: string, audience: string) => {
  return async (c: Context<{ Variables: AuthContextVariables }>, next: Next) => {
    const authHeader = c.req.header('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return c.json(
        {
          type: 'https://api.domain.com/errors/unauthorized',
          title: 'Unauthorized',
          status: 401,
          detail: 'Missing or malformed Authorization header with Bearer token',
        },
        401
      );
    }

    const token = authHeader.substring(7);

    try {
      const cryptoKey = await importSPKI(publicKeyPem, 'RS256');
      const { payload } = await jwtVerify(token, cryptoKey, {
        issuer,
        audience,
        algorithms: ['RS256'],
      });

      const parsedPayload = payload as EdgeJwtPayload;

      if (!parsedPayload.sub || !parsedPayload.tid || !Array.isArray(parsedPayload.roles)) {
        return c.json(
          {
            type: 'https://api.domain.com/errors/invalid-token',
            title: 'Forbidden',
            status: 403,
            detail: 'JWT payload is missing mandatory tenant or role claims',
          },
          403
        );
      }

      c.set('jwtPayload', parsedPayload);
      c.set('userId', parsedPayload.sub);
      c.set('tenantId', parsedPayload.tid);

      await next();
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Token verification failed';
      return c.json(
        {
          type: 'https://api.domain.com/errors/authentication-failed',
          title: 'Unauthorized',
          status: 401,
          detail: message,
        },
        401
      );
    }
  };
};

export const requireRoles = (requiredRoles: string[]) => {
  return async (c: Context<{ Variables: AuthContextVariables }>, next: Next) => {
    const payload = c.get('jwtPayload');
    if (!payload || !payload.roles) {
      return c.json({ title: 'Forbidden', status: 403, detail: 'Access context missing' }, 403);
    }

    const hasAccess = requiredRoles.some((role) => payload.roles.includes(role));
    if (!hasAccess) {
      return c.json(
        {
          type: 'https://api.domain.com/errors/insufficient-permissions',
          title: 'Forbidden',
          status: 403,
          detail: `User lacks required role: [${requiredRoles.join(', ')}]`,
        },
        403
      );
    }

    await next();
  };
};
```

---

### 1.3 Distributed Rate Limiting: KV Sliding Window vs. DO Token Bucket

| Metric / Dimension | KV Sliding Window | Durable Objects Token Bucket |
| :--- | :--- | :--- |
| **Consistency Model** | Eventual consistency (Edge replicated) | Strict serializability (Single-threaded DO) |
| **Sub-Millisecond Accuracy** | No (Replication lag: ~100–1000ms) | Yes (In-memory atomic updates) |
| **Under-Attack Behavior** | Slight over-allowance under global burst | Zero over-allowance; strictly enforces caps |
| **Edge Compute Cost** | Lowest (Standard KV read/write billing) | Moderate (DO state access and compute time) |
| **Ideal Use Case** | Public CDN edge protection, low-tier APIs | Financial gateways, checkout counters, strict LLM quotas |

#### Implementation A: Cloudflare KV Sliding Window Counter

```typescript
// src/middleware/kv-rate-limit.ts
import { Context, Next } from 'hono';

export interface KVRateLimitEnv {
  RATE_LIMIT_KV: KVNamespace;
}

export const kvRateLimit = (limit: number, windowSec: number = 60) => {
  return async (c: Context<{ Bindings: KVRateLimitEnv }>, next: Next) => {
    const clientIp = c.req.header('CF-Connecting-IP') || '127.0.0.1';
    const tenantId = c.req.header('X-Tenant-ID') || 'anonymous';
    const currentTime = Math.floor(Date.now() / 1000);
    const windowStart = currentTime - (currentTime % windowSec);
    const key = `ratelimit:${tenantId}:${clientIp}:${windowStart}`;

    const currentRaw = await c.env.RATE_LIMIT_KV.get(key);
    const count = currentRaw ? parseInt(currentRaw, 10) : 0;

    if (count >= limit) {
      c.res.headers.set('X-RateLimit-Limit', limit.toString());
      c.res.headers.set('X-RateLimit-Remaining', '0');
      c.res.headers.set('Retry-After', `${windowStart + windowSec - currentTime}`);

      return c.json(
        {
          type: 'https://api.domain.com/errors/rate-limit-exceeded',
          title: 'Too Many Requests',
          status: 429,
          detail: `Rate limit of ${limit} requests per ${windowSec}s exceeded.`,
        },
        429
      );
    }

    c.executionCtx.waitUntil(
      (async () => {
        const updated = count + 1;
        await c.env.RATE_LIMIT_KV.put(key, updated.toString(), {
          expirationTtl: windowSec * 2,
        });
      })()
    );

    c.res.headers.set('X-RateLimit-Limit', limit.toString());
    c.res.headers.set('X-RateLimit-Remaining', Math.max(0, limit - (count + 1)).toString());

    await next();
  };
};
```

#### Implementation B: Cloudflare Durable Objects Token Bucket

```typescript
// src/durable-objects/TokenBucketLimiter.ts
export interface DurableObjectEnv {
  TOKEN_BUCKET_DO: DurableObjectNamespace;
}

export class TokenBucketLimiter implements DurableObject {
  private state: DurableObjectState;
  private tokens: number = 0;
  private lastRefillTimestamp: number = Date.now();

  constructor(state: DurableObjectState) {
    this.state = state;
  }

  async fetch(request: Request): Promise<Response> {
    const url = new URL(request.url);
    const capacity = parseInt(url.searchParams.get('capacity') || '10', 10);
    const refillRatePerSec = parseFloat(url.searchParams.get('rate') || '1.0');
    const cost = parseInt(url.searchParams.get('cost') || '1', 10);

    await this.state.blockConcurrencyWhile(async () => {
      const stored = await this.state.storage.get<{ tokens: number; lastRefill: number }>('bucket_state');
      const now = Date.now();

      if (stored) {
        this.tokens = stored.tokens;
        this.lastRefillTimestamp = stored.lastRefill;
      } else {
        this.tokens = capacity;
        this.lastRefillTimestamp = now;
      }

      // Calculate elapsed token refill
      const elapsedSec = (now - this.lastRefillTimestamp) / 1000;
      const refilledTokens = elapsedSec * refillRatePerSec;
      this.tokens = Math.min(capacity, this.tokens + refilledTokens);
      this.lastRefillTimestamp = now;

      let allowed = false;
      let remaining = this.tokens;

      if (this.tokens >= cost) {
        this.tokens -= cost;
        remaining = this.tokens;
        allowed = true;
      }

      await this.state.storage.put('bucket_state', {
        tokens: this.tokens,
        lastRefill: this.lastRefillTimestamp,
      });

      return new Response(
        JSON.stringify({
          allowed,
          remaining: Math.floor(remaining),
          capacity,
          retryAfter: allowed ? 0 : Math.ceil((cost - this.tokens) / refillRatePerSec),
        }),
        {
          headers: { 'Content-Type': 'application/json' },
          status: allowed ? 200 : 429,
        }
      );
    });

    return new Response('Unhandled execution flow', { status: 500 });
  }
}
```

---

## 2. Relational Database Layer: Drizzle ORM + Cloudflare D1

### 2.1 Complete Relational Schema (`schema.ts`)

Implements a multi-tenant enterprise data architecture with primary keys generated at the edge, strictly typed foreign keys, enum constraints, and immutable audit trails.

```typescript
// src/db/schema.ts
import { sqliteTable, text, integer, index, uniqueIndex } from 'drizzle-orm/sqlite-core';
import { relations, sql } from 'drizzle-orm';

export const tenants = sqliteTable('tenants', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  slug: text('slug').notNull(),
  plan: text('plan', { enum: ['starter', 'scale', 'enterprise'] }).default('starter').notNull(),
  createdAt: integer('created_at', { mode: 'timestamp' })
    .default(sql`(strftime('%s', 'now'))`)
    .notNull(),
  updatedAt: integer('updated_at', { mode: 'timestamp' })
    .default(sql`(strftime('%s', 'now'))`)
    .notNull(),
}, (table) => ({
  slugIdx: uniqueIndex('tenants_slug_idx').on(table.slug),
}));

export const users = sqliteTable('users', {
  id: text('id').primaryKey(),
  tenantId: text('tenant_id')
    .notNull()
    .references(() => tenants.id, { onDelete: 'cascade' }),
  email: text('email').notNull(),
  role: text('role', { enum: ['admin', 'member', 'billing'] }).default('member').notNull(),
  isActive: integer('is_active', { mode: 'boolean' }).default(true).notNull(),
  createdAt: integer('created_at', { mode: 'timestamp' })
    .default(sql`(strftime('%s', 'now'))`)
    .notNull(),
}, (table) => ({
  tenantEmailIdx: uniqueIndex('users_tenant_email_idx').on(table.tenantId, table.email),
  tenantLookupIdx: index('users_tenant_id_idx').on(table.tenantId),
}));

export const auditLogs = sqliteTable('audit_logs', {
  id: text('id').primaryKey(),
  tenantId: text('tenant_id')
    .notNull()
    .references(() => tenants.id, { onDelete: 'cascade' }),
  userId: text('user_id').references(() => users.id, { onDelete: 'set null' }),
  action: text('action').notNull(),
  resourceType: text('resource_type').notNull(),
  resourceId: text('resource_id').notNull(),
  payloadJson: text('payload_json').notNull(),
  ipAddress: text('ip_address').notNull(),
  timestamp: integer('timestamp', { mode: 'timestamp' })
    .default(sql`(strftime('%s', 'now'))`)
    .notNull(),
}, (table) => ({
  tenantAuditIdx: index('audit_logs_tenant_idx').on(table.tenantId, table.timestamp),
}));

export const tenantRelations = relations(tenants, ({ many }) => ({
  users: many(users),
  auditLogs: many(auditLogs),
}));

export const userRelations = relations(users, ({ one, many }) => ({
  tenant: one(tenants, {
    fields: [users.tenantId],
    references: [tenants.id],
  }),
  auditLogs: many(auditLogs),
}));

export const auditLogRelations = relations(auditLogs, ({ one }) => ({
  tenant: one(tenants, {
    fields: [auditLogs.tenantId],
    references: [tenants.id],
  }),
  user: one(users, {
    fields: [auditLogs.userId],
    references: [users.id],
  }),
}));
```

---

### 2.2 `drizzle.config.ts`

Configured for native D1 local simulation and remote cloud migrations via Wrangler bindings:

```typescript
// drizzle.config.ts
import { defineConfig } from 'drizzle-kit';

export default defineConfig({
  schema: './src/db/schema.ts',
  out: './drizzle/migrations',
  dialect: 'sqlite',
  driver: 'd1-http',
  dbCredentials: {
    accountId: process.env.CLOUDFLARE_ACCOUNT_ID || '00000000000000000000000000000000',
    databaseId: process.env.CLOUDFLARE_D1_DATABASE_ID || '00000000-0000-0000-0000-000000000000',
    token: process.env.CLOUDFLARE_D1_API_TOKEN || 'missing_token_local_mode_only',
  },
  verbose: true,
  strict: true,
});
```

---

### 2.3 SQL Migration Script (`0000_init.sql`)

```sql
-- drizzle/migrations/0000_init.sql
CREATE TABLE IF NOT EXISTS `tenants` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`slug` text NOT NULL,
	`plan` text DEFAULT 'starter' NOT NULL,
	`created_at` integer DEFAULT (strftime('%s', 'now')) NOT NULL,
	`updated_at` integer DEFAULT (strftime('%s', 'now')) NOT NULL
);

CREATE UNIQUE INDEX IF NOT EXISTS `tenants_slug_idx` ON `tenants` (`slug`);

CREATE TABLE IF NOT EXISTS `users` (
	`id` text PRIMARY KEY NOT NULL,
	`tenant_id` text NOT NULL,
	`email` text NOT NULL,
	`role` text DEFAULT 'member' NOT NULL,
	`is_active` integer DEFAULT 1 NOT NULL,
	`created_at` integer DEFAULT (strftime('%s', 'now')) NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `tenants`(`id`) ON UPDATE no action ON DELETE cascade
);

CREATE UNIQUE INDEX IF NOT EXISTS `users_tenant_email_idx` ON `users` (`tenant_id`, `email`);
CREATE INDEX IF NOT EXISTS `users_tenant_id_idx` ON `users` (`tenant_id`);

CREATE TABLE IF NOT EXISTS `audit_logs` (
	`id` text PRIMARY KEY NOT NULL,
	`tenant_id` text NOT NULL,
	`user_id` text,
	`action` text NOT NULL,
	`resource_type` text NOT NULL,
	`resource_id` text NOT NULL,
	`payload_json` text NOT NULL,
	`ip_address` text NOT NULL,
	`timestamp` integer DEFAULT (strftime('%s', 'now')) NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `tenants`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE set null
);

CREATE INDEX IF NOT EXISTS `audit_logs_tenant_idx` ON `audit_logs` (`tenant_id`, `timestamp`);
```

---

### 2.4 D1 Repository Pattern Implementation

Encapsulates all atomic transactional operations and tenant-isolated data reads.

```typescript
// src/db/repository.ts
import { drizzle, DrizzleD1Database } from 'drizzle-orm/d1';
import { eq, and, desc } from 'drizzle-orm';
import * as schema from './schema';

export interface RepositoryEnv {
  DB: D1Database;
}

export class TenantRepository {
  private db: DrizzleD1Database<typeof schema>;

  constructor(d1: D1Database) {
    this.db = drizzle(d1, { schema });
  }

  async createTenantWithAdminUser(input: {
    tenantName: string;
    slug: string;
    adminEmail: string;
    ipAddress: string;
  }) {
    const tenantId = `tnt_${crypto.randomUUID()}`;
    const userId = `usr_${crypto.randomUUID()}`;
    const logId = `log_${crypto.randomUUID()}`;

    // Execute atomic operations through D1's native statement batching
    const result = await this.db.batch([
      this.db.insert(schema.tenants).values({
        id: tenantId,
        name: input.tenantName,
        slug: input.slug,
        plan: 'starter',
      }).returning(),

      this.db.insert(schema.users).values({
        id: userId,
        tenantId: tenantId,
        email: input.adminEmail,
        role: 'admin',
        isActive: true,
      }).returning(),

      this.db.insert(schema.auditLogs).values({
        id: logId,
        tenantId: tenantId,
        userId: userId,
        action: 'TENANT_PROVISIONED',
        resourceType: 'TENANT',
        resourceId: tenantId,
        payloadJson: JSON.stringify({ slug: input.slug, createdBy: input.adminEmail }),
        ipAddress: input.ipAddress,
      }),
    ]);

    return {
      tenant: result[0][0],
      adminUser: result[1][0],
    };
  }

  async getTenantUsers(tenantId: string, limit = 50, offset = 0) {
    return await this.db.query.users.findMany({
      where: eq(schema.users.tenantId, tenantId),
      limit: Math.min(limit, 100),
      offset: offset,
      orderBy: [desc(schema.users.createdAt)],
    });
  }

  async appendAuditLog(input: {
    tenantId: string;
    userId: string | null;
    action: string;
    resourceType: string;
    resourceId: string;
    payload: Record<string, unknown>;
    ipAddress: string;
  }) {
    return await this.db.insert(schema.auditLogs).values({
      id: `log_${crypto.randomUUID()}`,
      tenantId: input.tenantId,
      userId: input.userId,
      action: input.action,
      resourceType: input.resourceType,
      resourceId: input.resourceId,
      payloadJson: JSON.stringify(input.payload),
      ipAddress: input.ipAddress,
    }).returning();
  }
}
```

---

## 3. Edge Webhooks & Real-Time Communications

### 3.1 Stripe Webhook Cryptographic Verification (Native Web Crypto)

Eliminates the Node.js `stripe` SDK dependency. Implements RFC-compliant `v1` signature parsing and HMAC-SHA256 constant-time comparison entirely on Cloudflare edge primitives.

```typescript
// src/webhooks/stripe.ts
import { Context } from 'hono';

export interface StripeWebhookEnv {
  STRIPE_WEBHOOK_SECRET: string;
}

export const verifyStripeSignature = async (
  payload: string,
  signatureHeader: string,
  secret: string,
  toleranceSec = 300
): Promise<{ valid: boolean; error?: string }> => {
  const parts = signatureHeader.split(',');
  let timestamp = -1;
  const signatures: string[] = [];

  for (const item of parts) {
    const [key, value] = item.trim().split('=');
    if (key === 't') {
      timestamp = parseInt(value, 10);
    } else if (key === 'v1') {
      signatures.push(value);
    }
  }

  if (timestamp === -1 || signatures.length === 0) {
    return { valid: false, error: 'Malformed stripe-signature header' };
  }

  const currentSec = Math.floor(Date.now() / 1000);
  if (Math.abs(currentSec - timestamp) > toleranceSec) {
    return { valid: false, error: 'Signature timestamp outside tolerance range' };
  }

  const signedPayload = `${timestamp}.${payload}`;
  const enc = new TextEncoder();

  const key = await crypto.subtle.importKey(
    'raw',
    enc.encode(secret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );

  const signedBuffer = await crypto.subtle.sign('HMAC', key, enc.encode(signedPayload));
  const expectedSignatureHex = Array.from(new Uint8Array(signedBuffer))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');

  // Constant-time string equality check to eliminate timing side-channels
  const isValid = signatures.some((candidateSig) => {
    if (candidateSig.length !== expectedSignatureHex.length) return false;
    let match = 0;
    for (let i = 0; i < candidateSig.length; i++) {
      match |= candidateSig.charCodeAt(i) ^ expectedSignatureHex.charCodeAt(i);
    }
    return match === 0;
  });

  return isValid ? { valid: true } : { valid: false, error: 'Signature mismatch' };
};

export const handleStripeWebhook = async (c: Context<{ Bindings: StripeWebhookEnv }>) => {
  const signature = c.req.header('Stripe-Signature');
  if (!signature) {
    return c.json({ error: 'Missing Stripe-Signature header' }, 400);
  }

  const rawBody = await c.req.text();
  const secret = c.env.STRIPE_WEBHOOK_SECRET;

  const result = await verifyStripeSignature(rawBody, signature, secret);
  if (!result.valid) {
    return c.json({ error: result.error }, 400);
  }

  const event = JSON.parse(rawBody);

  switch (event.type) {
    case 'checkout.session.completed': {
      const session = event.data.object;
      // Process provision pipeline
      break;
    }
    case 'customer.subscription.deleted': {
      const subscription = event.data.object;
      // Process deprovision pipeline
      break;
    }
    default:
      // Acknowledge unhandled events to prevent retries
      break;
  }

  return c.json({ received: true }, 200);
};
```

---

### 3.2 GitHub Webhook Cryptographic Verification (`X-Hub-Signature-256`)

```typescript
// src/webhooks/github.ts
import { Context } from 'hono';

export interface GitHubWebhookEnv {
  GITHUB_WEBHOOK_SECRET: string;
}

export const verifyGitHubSignature = async (
  payload: string,
  sigHeader: string,
  secret: string
): Promise<boolean> => {
  if (!sigHeader.startsWith('sha256=')) {
    return false;
  }

  const cleanSig = sigHeader.substring(7);
  const enc = new TextEncoder();

  const key = await crypto.subtle.importKey(
    'raw',
    enc.encode(secret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['verify']
  );

  // Convert hex signature to ArrayBuffer
  const sigBytes = new Uint8Array(
    cleanSig.match(/.{1,2}/g)?.map((byte) => parseInt(byte, 16)) || []
  );

  return await crypto.subtle.verify('HMAC', key, sigBytes, enc.encode(payload));
};

export const handleGitHubWebhook = async (c: Context<{ Bindings: GitHubWebhookEnv }>) => {
  const signature = c.req.header('x-hub-signature-256');
  const event = c.req.header('x-github-event');

  if (!signature || !event) {
    return c.json({ error: 'Missing GitHub Webhook signature or event headers' }, 400);
  }

  const payload = await c.req.text();
  const isValid = await verifyGitHubSignature(payload, signature, c.env.GITHUB_WEBHOOK_SECRET);
