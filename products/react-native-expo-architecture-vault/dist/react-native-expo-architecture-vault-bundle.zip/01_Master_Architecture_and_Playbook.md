# Module 1: Complete Mobile Architecture & Expo Router Framework

This playbook establishes the baseline mobile enterprise architecture for production React Native applications utilizing Expo Router v3, Zustand for atomic state orchestration, hardware-backed native secure storage, and OS-compliant background task lifecycles.

---

## 1. System Architecture Blueprint

### 1.1 Production Directory Structure

```
.
├── app.json
├── package.json
├── tsconfig.json
├── app/
│   ├── _layout.tsx                 # Root layout: Providers, Navigation Guard, SplashScreen
│   ├── index.tsx                   # Bootstrapping route / Initial redirect engine
│   ├── (auth)/
│   │   ├── _layout.tsx             # Unauthenticated Stack Navigation
│   │   ├── login.tsx               # Primary credential entry
│   │   └── mfa.tsx                 # Multi-factor hardware / TOTP challenge
│   └── (app)/
│       ├── _layout.tsx             # Authenticated Drawer/Tabs layout with Native Guards
│       ├── (tabs)/
│       │   ├── _layout.tsx         # Bottom navigation tabs with native haptics
│       │   ├── index.tsx           # Dashboard / Feed
│       │   └── settings.tsx        # Hardware configuration, Biometrics, Session reset
│       └── modal/
│           └── edit-profile.tsx    # Presentation modal with native gesture sheets
├── src/
│   ├── components/                 # Atomic design UI elements (Zero business logic)
│   ├── hooks/                      # Custom React hooks (useNetworkStatus, useBiometrics)
│   ├── services/
│   │   ├── api/
│   │   │   ├── client.ts           # Axios instance with concurrency-locked token interceptor
│   │   │   └── endpoints.ts        # Typed endpoint contracts
│   │   ├── background/
│   │   │   └── sync-task.ts        # Expo TaskManager native background execution handler
│   │   └── storage/
│   │       ├── secure-storage.ts   # iOS Keychain / Android KeyStore hardware wrapper
│   │       └── state-storage.ts    # MMKV synchronous bridge for non-sensitive local cache
│   ├── stores/
│   │   ├── auth-store.ts           # Session identity, JWT, Biometric lock states
│   │   └── network-store.ts        # Reachability, sync queue pointers
│   └── types/
│       ├── auth.ts                 # DTOs, Session, and User payload definitions
│       └── navigation.ts           # Expo Router strictly typed parameter lists
```

### 1.2 Data & Control Flow Architecture

```
                                  +-----------------------------+
                                  | Native OS App Launch Event  |
                                  +--------------+--------------+
                                                 |
                                                 v
                                  +-----------------------------+
                                  | SplashScreen.preventAuto-   |
                                  | HideAsync() Native Freeze   |
                                  +--------------+--------------+
                                                 |
                                                 v
                          +----------------------------------------------+
                          |   RootLayout Bootstrap & Store Hydration     |
                          |   (Keychain -> Zustand -> Memory Cache)      |
                          +----------------------+-----------------------+
                                                 |
                   +-----------------------------+-----------------------------+
                   |                                                           |
                   v                                                           v
   +-------------------------------+                           +-------------------------------+
   | Session Token Missing/Expired |                           | Session Active & Non-Expired  |
   +---------------+---------------+                           +---------------+---------------+
                   |                                                           |
                   v                                                           v
   +-------------------------------+                           +-------------------------------+
   | Redirect -> /(auth)/login     |                           | Biometric Enclave Check?      |
   +-------------------------------+                           +---------------+---------------+
                                                                               |
                                                    +--------------------------+--------------------------+
                                                    | Passed / Disabled                                   | Failed / Locked
                                                    v                                                     v
                                    +-------------------------------+                     +-------------------------------+
                                    | Mount Dynamic App -> /(app)   |                     | Mount Local Hardware Gate     |
                                    +-------------------------------+                     | (Native Biometric Prompt)     |
                                                                                          +-------------------------------+
```

---

## 2. Enterprise Expo Router v3 Implementation

### 2.1 Native Deep Linking Configuration (`app.json`)

Configure universal linking for iOS (Universal Links) and Android (App Links) using explicit schemes and domain verification.

```json
{
  "expo": {
    "name": "ProductionVault",
    "slug": "production-vault",
    "version": "1.0.0",
    "scheme": "vaultapp",
    "ios": {
      "supportsTablet": false,
      "bundleIdentifier": "com.vault.production",
      "associatedDomains": [
        "applinks:vault.production.app"
      ],
      "infoPlist": {
        "NSFaceIDUsageDescription": "Vault uses Face ID to authenticate hardware access to your encrypted local enclave."
      }
    },
    "android": {
      "package": "com.vault.production",
      "adaptiveIcon": {
        "backgroundColor": "#0A0A0C"
      },
      "intentFilters": [
        {
          "action": "VIEW",
          "autoVerify": true,
          "data": [
            {
              "scheme": "https",
              "host": "vault.production.app",
              "pathPrefix": "/auth"
            },
            {
              "scheme": "https",
              "host": "vault.production.app",
              "pathPrefix": "/invite"
            }
          ],
          "category": ["BROWSABLE", "DEFAULT"]
        }
      ]
    },
    "plugins": [
      "expo-router",
      "expo-secure-store",
      "expo-task-manager",
      "expo-background-fetch",
      "expo-local-authentication"
    ]
  }
}
```

### 2.2 Dynamic Root Layout Engine (`app/_layout.tsx`)

This engine prevents layout thrashing, enforces biometric gates, checks network reachability, and routes navigation paths deterministically.

```tsx
import React, { useEffect, useState } from 'react';
import { Stack, useRouter, useSegments } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { useAuthStore } from '../src/stores/auth-store';
import { StatusBar } from 'expo-status-bar';
import { View, StyleSheet, ActivityIndicator } from 'react-native';

SplashScreen.preventAutoHideAsync().catch(() => {
  /* Native splash freeze applied */
});

export default function RootLayout() {
  const segments = useSegments();
  const router = useRouter();
  
  const isHydrated = useAuthStore((state) => state.isHydrated);
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);
  const isBiometricLocked = useAuthStore((state) => state.isBiometricLocked);
  const hydrateSession = useAuthStore((state) => state.hydrateSession);

  const [isLayoutReady, setIsLayoutReady] = useState<boolean>(false);

  useEffect(() => {
    async function initializeSystem() {
      try {
        await hydrateSession();
      } catch (error) {
        console.error('System hydration catastrophic failure:', error);
      } finally {
        setIsLayoutReady(true);
      }
    }
    initializeSystem();
  }, [hydrateSession]);

  useEffect(() => {
    if (!isLayoutReady || !isHydrated) return;

    const inAuthGroup = segments[0] === '(auth)';

    if (!isAuthenticated && !inAuthGroup) {
      router.replace('/(auth)/login');
    } else if (isAuthenticated && inAuthGroup) {
      router.replace('/(app)/(tabs)');
    }

    SplashScreen.hideAsync().catch(() => {
      /* Splash screen hidden */
    });
  }, [isHydrated, isLayoutReady, isAuthenticated, segments, router]);

  if (!isLayoutReady || !isHydrated) {
    return (
      <View style={styles.splashSurface}>
        <ActivityIndicator size="large" color="#4F46E5" />
      </View>
    );
  }

  return (
    <>
      <StatusBar style="light" />
      <Stack
        screenOptions={{
          headerShown: false,
          animation: 'fade',
          contentStyle: { backgroundColor: '#09090B' },
        }}
      >
        <Stack.Screen name="(auth)" options={{ animation: 'fade' }} />
        <Stack.Screen name="(app)" options={{ animation: 'default' }} />
        <Stack.Screen
          name="modal/edit-profile"
          options={{
            presentation: 'modal',
            animation: 'slide_from_bottom',
            headerShown: true,
            headerTitle: 'Security Profile',
            headerTintColor: '#FAFAFA',
            headerStyle: { backgroundColor: '#18181B' },
          }}
        />
      </Stack>
    </>
  );
}

const styles = StyleSheet.create({
  splashSurface: {
    flex: 1,
    backgroundColor: '#09090B',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
```

### 2.3 Authenticated App Layout (`app/(app)/_layout.tsx`)

```tsx
import React from 'react';
import { Stack, Redirect } from 'expo-router';
import { useAuthStore } from '../../src/stores/auth-store';

export default function AppLayout() {
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);
  const isBiometricLocked = useAuthStore((state) => state.isBiometricLocked);

  if (!isAuthenticated) {
    return <Redirect href="/(auth)/login" />;
  }

  return (
    <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: '#09090B' } }}>
      <Stack.Screen name="(tabs)" />
    </Stack>
  );
}
```

---

## 3. Hardware-Backed Secure Storage Layer

### 3.1 Hardware Enclave Adapter (`src/services/storage/secure-storage.ts`)

This production interface abstracts `expo-secure-store`. It enforces hardware-level encryption keys: `kSecAttrAccessibleWhenUnlockedThisDeviceOnly` on iOS and the Android Hardware-backed KeyStore. It handles invalid JSON extraction, serialization, and hardware-unsupported platform exceptions gracefully.

```typescript
import * as SecureStore from 'expo-secure-store';
import { Platform } from 'react-native';

export interface StoragePolicy {
  keychainService?: string;
  requireAuthentication?: boolean;
}

const DEFAULT_OPTIONS: SecureStore.SecureStoreOptions = {
  keychainAccessible: SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY,
  keychainService: 'VaultSecureService',
};

export class SecureEnclaveService {
  public static async setItem<T>(key: string, value: T, policy: StoragePolicy = {}): Promise<void> {
    const payload = JSON.stringify(value);
    const options: SecureStore.SecureStoreOptions = {
      ...DEFAULT_OPTIONS,
      keychainService: policy.keychainService ?? DEFAULT_OPTIONS.keychainService,
      requireAuthentication: policy.requireAuthentication ?? false,
    };

    try {
      await SecureStore.setItemAsync(key, payload, options);
    } catch (error) {
      throw new Error(`Enclave Write Failure: Key [${key}] - ${error instanceof Error ? error.message : 'Unknown'}`);
    }
  }

  public static async getItem<T>(key: string, policy: StoragePolicy = {}): Promise<T | null> {
    const options: SecureStore.SecureStoreOptions = {
      ...DEFAULT_OPTIONS,
      keychainService: policy.keychainService ?? DEFAULT_OPTIONS.keychainService,
      requireAuthentication: policy.requireAuthentication ?? false,
    };

    try {
      const rawData = await SecureStore.getItemAsync(key, options);
      if (!rawData) return null;
      return JSON.parse(rawData) as T;
    } catch (error) {
      console.warn(`Enclave Read Failure: Key [${key}] - Clearing invalid key state`);
      await this.removeItem(key, policy);
      return null;
    }
  }

  public static async removeItem(key: string, policy: StoragePolicy = {}): Promise<void> {
    const options: SecureStore.SecureStoreOptions = {
      ...DEFAULT_OPTIONS,
      keychainService: policy.keychainService ?? DEFAULT_OPTIONS.keychainService,
    };

    try {
      await SecureStore.deleteItemAsync(key, options);
    } catch (error) {
      throw new Error(`Enclave Purge Failure: Key [${key}] - ${error instanceof Error ? error.message : 'Unknown'}`);
    }
  }
}
```

### 3.2 Secure Multi-Lock Mutex Interceptor (`src/services/api/client.ts`)

Concurrently executing API calls must not trigger distinct refresh routines. This network client enforces a promise-based mutex barrier preventing race conditions on access token expiration.

```typescript
import axios, { AxiosError, AxiosRequestConfig, InternalAxiosRequestConfig } from 'axios';
import { useAuthStore } from '../../stores/auth-store';

const API_BASE_URL = 'https://vault.production.app/api/v1';

export const apiClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: 15000,
  headers: {
    'Content-Type': 'application/json',
    Accept: 'application/json',
  },
});

let isRefreshing = false;
let failedQueue: Array<{
  resolve: (value?: unknown) => void;
  reject: (reason?: unknown) => void;
}> = [];

const processQueue = (error: Error | null) => {
  failedQueue.forEach((prom) => {
    if (error) {
      prom.reject(error);
    } else {
      prom.resolve();
    }
  });
  failedQueue = [];
};

apiClient.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    const token = useAuthStore.getState().tokens?.accessToken;
    if (token && config.headers) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error: AxiosError) => Promise.reject(error)
);

apiClient.interceptors.response.use(
  (response) => response,
  async (error: AxiosError) => {
    const originalRequest = error.config as InternalAxiosRequestConfig & { _retry?: boolean };

    if (error.response?.status === 401 && !originalRequest._retry) {
      if (isRefreshing) {
        return new Promise((resolve, reject) => {
          failedQueue.push({ resolve, reject });
        })
          .then(() => apiClient(originalRequest))
          .catch((err) => Promise.reject(err));
      }

      originalRequest._retry = true;
      isRefreshing = true;

      try {
        const currentRefreshToken = useAuthStore.getState().tokens?.refreshToken;
        if (!currentRefreshToken) {
          throw new Error('No refresh token present in memory store');
        }

        const refreshResponse = await axios.post(`${API_BASE_URL}/auth/refresh`, {
          refreshToken: currentRefreshToken,
        });

        const { accessToken, refreshToken: newRefreshToken } = refreshResponse.data;

        await useAuthStore.getState().setTokens({
          accessToken,
          refreshToken: newRefreshToken,
        });

        processQueue(null);
        return apiClient(originalRequest);
      } catch (refreshError) {
        processQueue(refreshError instanceof Error ? refreshError : new Error('Refresh Failure'));
        await useAuthStore.getState().terminateSession();
        return Promise.reject(refreshError);
      } finally {
        isRefreshing = false;
      }
    }

    return Promise.reject(error);
  }
);
```

---

## 4. Native State Management with Zustand

### 4.1 Production Auth Store (`src/stores/auth-store.ts`)

Features atomic selector compliance, secure hardware persistence isolation, and strict state machine lifecycle progression: `IDLE` -> `HYDRATING` -> `AUTHENTICATED` / `UNAUTHENTICATED`.

```typescript
import { create } from 'zustand';
import { SecureEnclaveService } from '../services/storage/secure-storage';
import * as LocalAuthentication from 'expo-local-authentication';

export interface TokenPayload {
  accessToken: string;
  refreshToken: string;
}

export interface UserProfile {
  id: string;
  email: string;
  orgId: string;
  role: 'superadmin' | 'operator' | 'auditor';
}

interface AuthState {
  tokens: TokenPayload | null;
  user: UserProfile | null;
  isAuthenticated: boolean;
  isBiometricLocked: boolean;
  isHydrated: boolean;
  setTokens: (tokens: TokenPayload) => Promise<void>;
  setUser: (user: UserProfile) => void;
  hydrateSession: () => Promise<void>;
  unlockWithBiometrics: () => Promise<boolean>;
  terminateSession: () => Promise<void>;
}

const SECURE_STORE_KEYS = {
  TOKENS: 'usr_tk_session',
  USER: 'usr_pf_session',
  BIOMETRIC_PREF: 'usr_bio_flag',
};

export const useAuthStore = create<AuthState>((set, get) => ({
  tokens: null,
  user: null,
  isAuthenticated: false,
  isBiometricLocked: false,
  isHydrated: false,

  hydrateSession: async () => {
    try {
      const [tokens, user] = await Promise.all([
        SecureEnclaveService.getItem<TokenPayload>(SECURE_STORE_KEYS.TOKENS),
        SecureEnclaveService.getItem<UserProfile>(SECURE_STORE_KEYS.USER),
      ]);

      if (tokens?.accessToken && user?.id) {
        const hasHardware = await LocalAuthentication.hasHardwareAsync();
        const isEnrolled = await LocalAuthentication.isEnrolledAsync();
        const requireBio = hasHardware && isEnrolled;

        set({
          tokens,
          user,
          isAuthenticated: true,
          isBiometricLocked: requireBio,
          isHydrated: true,
        });
      } else {
        set({
          tokens: null,
          user: null,
          isAuthenticated: false,
          isBiometricLocked: false,
          isHydrated: true,
        });
      }
    } catch (e) {
      set({
        tokens: null,
        user: null,
        isAuthenticated: false,
        isBiometricLocked: false,
        isHydrated: true,
      });
    }
  },

  setTokens: async (tokens: TokenPayload) => {
    await SecureEnclaveService.setItem(SECURE_STORE_KEYS.TOKENS, tokens);
    set({ tokens, isAuthenticated: true });
  },

  setUser: async (user: UserProfile) => {
    await SecureEnclaveService.setItem(SECURE_STORE_KEYS.USER, user);
    set({ user });
  },

  unlockWithBiometrics: async () => {
    try {
      const result = await LocalAuthentication.authenticateAsync({
        promptMessage: 'Authorize Hardware Identity',
        fallbackLabel: 'Enter Passcode',
        disableDeviceFallback: false,
        cancelLabel: 'Cancel',
      });

      if (result.success) {
        set({ isBiometricLocked: false });
        return true;
      }
      return false;
    } catch {
      return false;
    }
  },

  terminateSession: async () => {
    await Promise.all([
      SecureEnclaveService.removeItem(SECURE_STORE_KEYS.TOKENS),
      SecureEnclaveService.removeItem(SECURE_STORE_KEYS.USER),
    ]);
    set({
      tokens: null,
      user: null,
      isAuthenticated: false,
      isBiometricLocked: false,
    });
  },
}));
```

---

## 5. Native Background Execution & TaskManager Lifecycles

### 5.1 Native Registration Architecture (`src/services/background/sync-task.ts`)

Executes background tasks adhering to iOS `Background Fetch` rate-limits and Android Doze constraints. It synchronizes out-of-band operational states directly via native runtimes without invoking unneeded UI components.

```typescript
import * as TaskManager from 'expo-task-manager';
import * as BackgroundFetch from 'expo-background-fetch';
import { SecureEnclaveService } from '../storage/secure-storage';
import axios from 'axios';

export const BACKGROUND_SYNC_TASK = 'VAULT_BACKGROUND_OFFLINE_SYNC';

interface SyncManifest {
  lastSyncedTimestamp: number;
  pendingTransactions: string[];
}

TaskManager.defineTask(BACKGROUND_SYNC_TASK, async () => {
  const now = Date.now();
  try {
    const rawTokens = await SecureEnclaveService.getItem<{ accessToken: string }>('usr_tk_session');
    
    if (!rawTokens?.accessToken) {
      return BackgroundFetch.BackgroundFetchResult.NoData;
    }

    const payload = await SecureEnclaveService.getItem<SyncManifest>('local_sync_manifest');
    
    if (!payload || payload.pendingTransactions.length === 0) {
      return BackgroundFetch.BackgroundFetchResult.NoData;
    }

    const response = await axios.post(
      'https://vault.production.app/api/v1/sync/drain',
      { transactions: payload.pendingTransactions },
      {
        headers: {
          Authorization: `Bearer ${rawTokens.accessToken}`,
          'X-Client-Timeout': '10000',
        },
        timeout: 9500,
      }
    );

    if (response.status === 200) {
      await SecureEnclaveService.setItem<SyncManifest>('local_sync_manifest', {
        lastSyncedTimestamp: now,
        pendingTransactions: [],
      });
      return BackgroundFetch.BackgroundFetchResult.NewData;
    }

    return BackgroundFetch.BackgroundFetchResult.Failed;
  } catch (error) {
    return BackgroundFetch.BackgroundFetchResult.Failed;
  }
});

export async function registerBackgroundSyncAsync(): Promise<void> {
  const isRegistered = await TaskManager.isTaskRegisteredAsync(BACKGROUND_SYNC_TASK);
  if (isRegistered) {
    return;
  }

  await BackgroundFetch.registerTaskAsync(BACKGROUND_SYNC_TASK, {
    minimumInterval: 15 * 60, // 15 Minutes (OS Discretionary Execution Window)
    stopOnTerminate: false,   // Android specific: Resists application task kill
    startOnBoot: true,        // Android specific: Native receiver bootstrap hook
  });
}

export async function unregisterBackgroundSyncAsync(): Promise<void> {
  const isRegistered = await TaskManager.isTaskRegisteredAsync(BACKGROUND_SYNC_TASK);
  if (isRegistered) {
    await BackgroundFetch.unregisterTaskAsync(BACKGROUND_SYNC_TASK);
  }
}
```

---

## 6. Production Verification Matrix & Audit Checklist

Use this audit protocol before promoting builds through TestFlight internal/external testing or Google Play Closed Testing tracks.

### 6.1 Architecture Audit Matrix

| Architectural Domain | Audit Standard | Verification Vector | Status Flag | Remediation Path |
| :--- | :--- | :--- | :--- | :--- |
| **Native Storage Security** | Tokens must not persist in unencrypted contexts. | Inspect raw SQLite, Async Storage, & `NSUserDefaults` files. | Required | Flush to `expo-secure-store` with `WHEN_UNLOCKED_THIS_DEVICE_ONLY`. |
| **Token Refresh Race Barrier** | Overlapping async queries must execute on a single refreshed token. | Throttle connection to 200ms, burst 10 requests against expired access tokens. | Required | Verify `isRefreshing` Mutex locks 9 requests; asserts exactly 1 refresh call. |
| **Navigation State Invariants** | Unauthenticated deep links must redirect to auth without layout flash. | Invoke deep link `vaultapp://modal/edit-profile` when cache is cold. | Required | Confirm `_layout.tsx` routes to `(auth)/login` without rendering the dashboard. |
| **Deep Link Scheme Handlers** | Apple App Site Association (AASA) / Android Digital Asset Links. | Run verification via `curl -IL https://vault.production.app/.well-known/assetlinks.json`. | Required | Correct `app.json` associatedDomains prefix configuration. |
| **Background OS Kill Resiliency**| Tasks must handle app termination cleanly on Android & iOS. | Force stop UI via Task Switcher, simulate interval in Xcode/ADB. | Required | Set `stopOnTerminate: false` and register task outside of the component tree. |

### 6.2 Pre-Flight Production Checklist

- [ ] **Native Enclave Access**: Ensure all calls to `SecureEnclaveService` include fallback blocks for instances where the user resets their hardware lock or device passcode.
- [ ] **Navigation Boundaries**: Verify that no unauthenticated component mounts inside `app/(app)` before `hydrateSession()` finishes, avoiding flashes of unauthenticated content.
- [ ] **Android Doze Exemption Safety**: Verify that `expo-background-fetch` intervals do not fall below 15 minutes, which triggers OS-level throttling and battery management blocks.
- [ ] **Axios Concurrency Safety**: Confirm that failed requests in `failedQueue` reject properly when a refresh fails, preventing zombie promises from hanging indefinitely.
- [ ] **Memory Leaks in Layout Listeners**: Make sure all event listeners attached to URL dispatchers or push tokens clean up properly during root component unmounting.
